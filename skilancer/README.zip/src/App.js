// import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Home from './components/Home.js/home';
import Login from './components/login/login';
import Contact from './components/contact/contact';

function App() {

  function PrivateRoute({ element }) {
    const isLoggedin = localStorage.getItem("Access_token") !== null 
    console.log(isLoggedin)
  
    if(!isLoggedin){
      return <Navigate to="/login" />
    }
  
    return element;
  }
  
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<PrivateRoute element={<Home />} />} />
        <Route path="/contact" element={<PrivateRoute element={<Contact />} />} /> 
      </Routes>
    </Router>
  );
}

export default App;
