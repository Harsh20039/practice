import Navbar from "../Navbar/navbar";

function Contact(){
return(
<>
<div className="">
<Navbar/>
<div className="homeWelcom container-fluid  ">
          <div className="">
            Welcome to Display data neeraj
            <p className="fs-2 text-center " style={{ color: "white" }}>
              Hindustan Unilever Limited
            </p>
          </div>
        </div>



</div>


</>)
}
export default Contact;