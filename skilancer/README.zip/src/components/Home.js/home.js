import { useEffect, useState } from "react";
import Navbar from "../Navbar/navbar";
import "./home.css";


function Home() {
  const [resdata, setResData] = useState([]);

  const getData = async () => {
    try {
      const data = await fetch("http://localhost:5000/auth");
      const dada = await data.json();
      setResData(dada);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <>

      <div className="Home  ">
    <Navbar/>
        <div className="homeWelcom container-fluid  ">
          <div className="">
            Welcome to Display data neeraj
            <p className="fs-2 text-center " style={{ color: "white" }}>
              Hindustan Unilever Limited
            </p>
          </div>
        </div>

        <table className="table  table-striped">
          <thead>
            <tr className="tee">
              <th scope="col">ID</th>
              <th scope="col">Timestamp</th>
              <th scope="col">Runtime Today</th>
              <th scope="col">Runtime Totel</th>
              <th scope="col">Battery Level</th>
              <th scope="col">Max Packet Number</th>
              <th scope="col">IR_1</th>
              <th scope="col">IR_2</th>
              <th scope="col">Status</th>
              <th scope="col">Packet Details</th>
              <th scope="col">More Details</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <th scope="row">1</th>
              <td>
                <p data-bs-target="#exampleModalToggle" data-bs-toggle="modal">
                  js
                </p>
              </td>
              <td>Otto</td>
            </tr>
          </tbody>
        </table>
        {/* popup */}

        <>
          <div
            className="modal fade"
            id="exampleModalToggle"
            aria-hidden="true"
            aria-labelledby="exampleModalToggleLabel"
            tabIndex={-1}
          >
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content">
                <div className="p-3">
                <div className="text-center">
                <span className="d-flex ">
                
                <h1 className="modal-title fs-5" >Data packets Details  </h1> 
                  <button
               
                    type="button"
                    className="btn-close ms-auto"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  />
       </span>
                  <hr />
                  {/* table */}
                  <table className="table  table-striped">
          <thead>
            <tr className="tee">
              <th scope="col">Timestamp (DD/MM/YY)</th>
              <th scope="col">Total Runs</th>
              <th scope="col">Runtime Today</th>
              <th scope="col">Runtime Total</th>
              
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>17/04/2024</td>
              <td>1</td>
              <td>0</td>
              <td>0</td>
            </tr>
          </tbody>
        </table>
   


   {/* end table */}
   </div>
                </div>
              </div>
            </div>
          </div>
        </>

        {/* end popup  */}
      </div>
    </>
  );
}

export default Home;
