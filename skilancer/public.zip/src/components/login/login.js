import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";


function Login() {
  const [passwordType, setPasswordType] = useState("password");
  const [loginData, setLoginData] = useState(
    { userName: "", password: "" }
  );
  const navigate=useNavigate()

  const submit = (e) => {
    e.preventDefault();
    console.log(loginData);
    loginsend();
    setLoginData({ userName: "", password: "" })
  };

  const loginsend = async () => {
    try {
      const loginUser = await fetch("http://localhost:5000/user/login", {
          method: "POST",
          body: JSON.stringify(loginData),

          headers: {
              'Content-type': 'application/json; charset=UTF-8',
          }
      })
      const res = await loginUser.json()
      
      if (res.error) {
        alert(res.error);
        
    } else if(res.message === "User login successful"){
        localStorage.setItem('Access_token', res.token); 
      
    }
  }
  catch (err) {
      console.log(err)
  }

  
  
  };

  return (
    <div className="container-fluid main">
      <div className="login d-flex ">
        <div className="loginchild1 ">
          <div className="text-center mt-5 fs-1">
            <i><b>Login</b></i>
          </div>
          <form
            onSubmit={submit}
            className=""
            style={{ width: "80%", paddingTop: 40, paddingLeft: 70 }}
          >
            <div className="mb-3">
              <label htmlFor="exampleInputEmail1" className="form-label">
                <i><b>User Name</b></i>
              </label>
              <input
                type="text"
                required={true}
                className="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                value={loginData.userName}
                onChange={(e) =>
                  setLoginData({ ...loginData, userName: e.target.value })
                }
              />
              <div id="emailHelp" className="form-text">
                We'll never share your Username with anyone else.
              </div>
            </div>
            <div className="mb-3">
              <label htmlFor="exampleInputPassword1" className="form-label">
                <i><b>Password</b></i>
              </label>
              <input
                type={passwordType}
                required={true}
                className="form-control"
                id="exampleInputPassword1"
                value={loginData.password}
                onChange={(e) =>
                  setLoginData({ ...loginData, password: e.target.value })
                }
              />
              <input
                type="checkbox"
                onChange={(e) =>
                  setPasswordType(e.target.checked ? "text" : "password")
                }
              />
            </div>
            <button
             
              type="submit"
              className="fs-5  form-control btn  loginbtn" >
              Login
            </button>
          </form>
        </div>
        <div className="loginchild2 d-flex align-items-center">
          <div className="welcome ">Welcome to login</div>
        </div>
      </div>
    </div>
  );
}

export default Login;
