import { Link, useNavigate } from 'react-router-dom';
import './navbar.css';

function Navbar() {
    const navigate = useNavigate();

    function logOut() {
        navigate('/');
    }

    return (
        <>
            <nav className="nav d-flex">
                <div className="logo ms-3">
                    Skilancer
                </div>
                <div className="child ms-auto me-3">
                    <Link className="link" to="/home">Home</Link>
                    <Link className="link" to="/contact">Contact</Link>
                    <a className="link" style={{cursor:" pointer"}} onClick={logOut}>Log Out</a>
                </div>
            </nav>
        </>
    );
}

export default Navbar;
